<?php
$module_name = 'ent_Entrevues';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'ent_entrevues_users_name',
            'label' => 'LBL_ENT_ENTREVUES_USERS_FROM_USERS_TITLE',
          ),
          1 => 
          array (
            'name' => 'date_entrevue',
            'label' => 'LBL_DATE_ENTREVUE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'comment_refere',
            'label' => 'LBL_COMMENT_REFERE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'org_ref_recrut',
            'label' => 'LBL_ORG_REF_RECRUT',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
;
?>
