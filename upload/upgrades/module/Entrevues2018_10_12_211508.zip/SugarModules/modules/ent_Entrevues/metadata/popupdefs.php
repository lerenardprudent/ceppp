<?php
$popupMeta = array (
    'moduleMain' => 'ent_Entrevues',
    'varName' => 'ent_Entrevues',
    'orderBy' => 'ent_entrevues.name',
    'whereClauses' => array (
  'date_entrevue' => 'ent_entrevues.date_entrevue',
),
    'searchInputs' => array (
  4 => 'date_entrevue',
),
    'searchdefs' => array (
  'date_entrevue' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_ENTREVUE',
    'width' => '10%',
    'name' => 'date_entrevue',
  ),
),
);
