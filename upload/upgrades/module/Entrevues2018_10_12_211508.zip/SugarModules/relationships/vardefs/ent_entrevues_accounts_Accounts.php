<?php
// created: 2018-10-12 21:15:08
$dictionary["Account"]["fields"]["ent_entrevues_accounts"] = array (
  'name' => 'ent_entrevues_accounts',
  'type' => 'link',
  'relationship' => 'ent_entrevues_accounts',
  'source' => 'non-db',
  'module' => 'ent_Entrevues',
  'bean_name' => 'ent_Entrevues',
  'side' => 'right',
  'vname' => 'LBL_ENT_ENTREVUES_ACCOUNTS_FROM_ENT_ENTREVUES_TITLE',
);
